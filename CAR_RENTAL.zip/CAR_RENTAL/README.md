# Car Rental System (Console, OTP-based Login)

- Weekly rental fee: **$50/week**
- Late fee on returning: **$10 per late day**
- Age < 18 → cannot view cars
- Expired licence → cannot view/book
- **Login is OTP-based:** Password check -> OTP generated -> Verify OTP to complete login
- **No QR Code / No OTP elsewhere**; future plan = **AT-card tap-on/tap-off** (Task 2 innovation)

## Run
```bash
python main.py
```
Seeded users:
- admin / admin123
- cust / cust123
- teen / teen123
