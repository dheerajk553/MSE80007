# database.py — SQLite setup, connection, and seeding

import sqlite3
from pathlib import Path
from datetime import date

DB_PATH = Path("car_rental.db")

def get_connection():
    conn = sqlite3.connect(DB_PATH)
    return conn

def setup_database():
    conn = get_connection()
    cur = conn.cursor()

    # Users
    cur.execute("""
    CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY,
        password TEXT NOT NULL,
        role     TEXT NOT NULL CHECK (role IN ('admin','customer')),
        name     TEXT,
        age      INTEGER,
        phone    TEXT,
        address  TEXT,
        licence_expiry TEXT
    );
    """)

    # Cars
    cur.execute("""
    CREATE TABLE IF NOT EXISTS cars (
        id       INTEGER PRIMARY KEY AUTOINCREMENT,
        make     TEXT NOT NULL,
        model    TEXT NOT NULL,
        year     INTEGER NOT NULL,
        mileage  INTEGER NOT NULL,
        available INTEGER NOT NULL DEFAULT 1
    );
    """)

    # Bookings
    cur.execute("""
    CREATE TABLE IF NOT EXISTS bookings (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_username TEXT NOT NULL,
        car_id    INTEGER NOT NULL,
        start_date TEXT NOT NULL,
        end_date   TEXT NOT NULL,
        fee        INTEGER NOT NULL,
        status     TEXT NOT NULL,
        payment_status TEXT NOT NULL,
        payment_method TEXT,
        payment_date   TEXT,
        FOREIGN KEY(customer_username) REFERENCES users(username),
        FOREIGN KEY(car_id) REFERENCES cars(id)
    );
    """)

    # Booking OTPs
    cur.execute("""
    CREATE TABLE IF NOT EXISTS booking_otps (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL,
        code       TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        used       INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY(booking_id) REFERENCES bookings(id)
    );
    """)

    conn.commit()
    conn.close()

def seed_defaults():
    """Insert default rows if empty (idempotent)."""
    conn = get_connection()
    cur = conn.cursor()

    # Default users
    defaults = [
        ("admin", "admin123", "admin", "Administrator", 30, "0000000000", "HQ", "2099-12-31"),
        ("cust",  "cust123",  "customer", "Dheeraj", 23, "0226281374", "Auckland", "2026-12-12"),
        ("teen",  "teen123",  "customer", "Test Teen", 16, "0000000001", "Auckland", "2026-12-12"),
    ]
    for u in defaults:
        cur.execute("SELECT 1 FROM users WHERE username=?", (u[0],))
        if not cur.fetchone():
            cur.execute("""INSERT INTO users(username,password,role,name,age,phone,address,licence_expiry)
                           VALUES (?,?,?,?,?,?,?,?)""", u)

    # Default cars (AUDI, NISSAN, HONDA)
    cars = [
        ("AUDI",   "A4",       2018, 45000, 1),
        ("NISSAN", "X-Trail",  2019, 38000, 1),
        ("HONDA",  "Civic",    2020, 30000, 1),
    ]
    cur.execute("SELECT COUNT(*) FROM cars")
    if cur.fetchone()[0] == 0:
        for c in cars:
            cur.execute("""INSERT INTO cars(make,model,year,mileage,available)
                           VALUES (?,?,?,?,?)""", c)

    conn.commit()
    conn.close()

def get_user(username: str):
    conn = get_connection()
    cur = conn.cursor()
    row = cur.execute("SELECT username,password,role,name,age,phone,address,licence_expiry FROM users WHERE username=?",
                      (username,)).fetchone()
    conn.close()
    return row
