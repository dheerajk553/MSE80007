# main.py — Role-based console menu (Customer/Admin)

from database import setup_database, seed_defaults
from user_manager import register_user, login_user
from car_manager import (
    add_car, view_available_cars_for_customer, list_all_cars,
    update_car_availability, delete_car
)
from booking_manager import (
    create_booking, approve_booking, reject_booking, return_car,
    confirm_booking_with_otp, mark_payment, view_all_bookings,
    view_my_bookings
)
from datetime import datetime

def prompt_int(msg):
    while True:
        v = input(msg).strip()
        if v.isdigit():
            return int(v)
        print("Please enter a number (e.g., 1).")

def prompt_date(msg):
    while True:
        s = input(msg).strip()
        try:
            datetime.strptime(s, "%Y-%m-%d")
            return s
        except ValueError:
            print("Use format YYYY-MM-DD (e.g., 2025-09-12).")

def print_menu(role):
    print("\n=== Car Rental System Menu ===")
    if role is None:
        for key, label in [("1","Register"),("2","Login"),("16","Exit")]:
            print(f"{key}. {label}")
    elif role == "customer":
        for key, label in [
            ("1","Register"), ("2","Login"), ("15","Logout"),
            ("4","View Available Cars"), ("5","Create Booking"),
            ("6","Confirm Booking (OTP)"), ("17","View My Bookings"),
            ("16","Exit")
        ]:
            print(f"{key}. {label}")
    elif role == "admin":
        for key, label in [
            ("1","Register"), ("2","Login"), ("15","Logout"),
            ("3","Add Car"), ("7","Approve Booking"), ("8","Reject Booking"),
            ("9","Return Car"), ("10","Mark Payment as PAID"),
            ("11","List All Cars"), ("12","Update Car Availability"),
            ("13","Delete Car"), ("14","View All Bookings"),
            ("16","Exit")
        ]:
            print(f"{key}. {label}")

def main():
    setup_database()
    seed_defaults()

    logged_in_user = None
    logged_in_role = None

    while True:
        print_menu(logged_in_role)
        ch = input("Choice: ").strip()

        if ch == "1":
            print("\n-- Register --")
            username = input("Username: ").strip()
            password = input("Password: ").strip()
            role = input("Role (admin/customer): ").strip().lower()
            name = input("Name: ").strip()
            age = prompt_int("Age: ")
            phone = input("Phone: ").strip()
            address = input("Address: ").strip()
            license_expiry = prompt_date("Licence Expiry (YYYY-MM-DD): ")
            register_user(username, password, role, name, age, phone, address, license_expiry)

        elif ch == "2":
            print("\n-- Login --")
            username = input("Username: ").strip()
            password = input("Password: ").strip()
            role = login_user(username, password)
            if role:
                logged_in_user = username
                logged_in_role = role
                print(f"Logged in as {role}")
            else:
                print("Invalid credentials.")

        elif ch == "3" and logged_in_role == "admin":
            print("\n-- Add Car --")
            make = input("Make: ").strip()
            model = input("Model: ").strip()
            year = prompt_int("Year: ")
            mileage = prompt_int("Mileage: ")
            add_car(make, model, year, mileage)

        elif ch == "4" and logged_in_role == "customer":
            print("\n-- Available Cars --")
            view_available_cars_for_customer(logged_in_user)

        elif ch == "5" and logged_in_role == "customer":
            print("\n-- Create Booking -- (Dates must be YYYY-MM-DD)")
            car_id = prompt_int("Car ID: ")
            start_date = prompt_date("Start date: ")
            end_date   = prompt_date("End date  : ")
            create_booking(logged_in_user, car_id, start_date, end_date)

        elif ch == "6" and logged_in_role == "customer":
            print("\n-- Confirm Booking (OTP) --")
            bid = prompt_int("Booking ID: ")
            otp = input("OTP: ").strip()
            confirm_booking_with_otp(bid, otp)

        elif ch == "7" and logged_in_role == "admin":
            bid = prompt_int("Booking ID to approve: ")
            approve_booking(bid)

        elif ch == "8" and logged_in_role == "admin":
            bid = prompt_int("Booking ID to reject: ")
            reject_booking(bid)

        elif ch == "9" and logged_in_role == "admin":
            print("\n-- Return Car --")
            bid = prompt_int("Booking ID: ")
            actual = prompt_date("Actual return date (YYYY-MM-DD): ")
            return_car(bid, actual)

        elif ch == "10" and logged_in_role == "admin":
            print("\n-- Mark Payment --")
            bid = prompt_int("Booking ID: ")
            method = input("Payment method (CASH/CARD/ONLINE): ").strip().upper()
            mark_payment(bid, method)

        elif ch == "11" and logged_in_role == "admin":
            list_all_cars()

        elif ch == "12" and logged_in_role == "admin":
            car_id = prompt_int("Car ID: ")
            available = prompt_int("Available? (1 yes / 0 no): ") == 1
            update_car_availability(car_id, available)

        elif ch == "13" and logged_in_role == "admin":
            car_id = prompt_int("Car ID to delete: ")
            delete_car(car_id)

        elif ch == "14" and logged_in_role == "admin":
            view_all_bookings()

        elif ch == "15":
            logged_in_user = None
            logged_in_role = None
            print("Logged out.")

        elif ch == "16":
            print("Thank you. Exiting...")
            break

        elif ch == "17" and logged_in_role == "customer":
            print("\n-- My Bookings --")
            view_my_bookings(logged_in_user)

        else:
            print(" Invalid choice or not allowed for your role.")

if __name__ == "__main__":
    main()
