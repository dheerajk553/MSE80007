# user_manager.py — Register and Login

from database import get_connection

def register_user(username, password, role, name, age, phone, address, licence_expiry):
    role = (role or "").lower()
    if role not in ("admin", "customer"):
        print(" Role must be 'admin' or 'customer'.")
        return

    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT 1 FROM users WHERE username=?", (username,))
    if cur.fetchone():
        print("Username already exists.")
        conn.close()
        return

    cur.execute("""INSERT INTO users(username,password,role,name,age,phone,address,licence_expiry)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (username, password, role, name, age, phone, address, licence_expiry))
    conn.commit()
    conn.close()
    print("Registration successful.")

def login_user(username, password):
    conn = get_connection()
    cur = conn.cursor()
    row = cur.execute("SELECT role FROM users WHERE username=? AND password=?",
                      (username, password)).fetchone()
    conn.close()
    if row:
        return row[0]   # role
    return None
