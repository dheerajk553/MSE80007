Test Cases-Car Rental System (Python+ SQLite3).

Build: console (Python 3 + SQLite3)  
Users:  
Admin - admin / admin123  
Customer (eligible) cust / cust123 (age 23, licence valid)  
Customer (underage) -teen /teen123 (16 years old)

Cars (selected=1 on fresh DB): AUDI A4, NISSAN X-Trail, HONDA Civic (all available=1)

1) Registration & Login

TC1 - Customer registration (success)  
Hearts: 1 Register - role customer, good details (age [?] 18, licence future).  
Meanwhile, registration should be successful. User appears in users.

TC2 - Register with role of invalidity (error)  
Operations: role set to anything.  
Expected: "Should be role 'admin' or customer role.

TC3 - Login admin (success)  
Steps: 2 Login - admin / admin123.  
Expected: "Logged in as admin". Admin menu only.

TC4 - Login customer (success)  
Steps: 2 Login - cust / cust123.  
As expected: "Signed in as customer. Customer menu only.

TC5 - Wrong password (invalid)  
Instructions: 2 Log in - incorrect username, correct password.  
Anticipated: "Unacceptable credentials.

2) Eligibility (Age & Licence)

TC6 - See cars (eligible customer)  
Login: cust / cust123.  
Steps: "View Available Cars".  
Expected: Seated cars printed.

TC7 - View cars (under 18)  
Login: teen / teen123.  
Steps: "View Available Cars".  
Predicted: You should be 18 years and above to see cars.

TC8 - View cars (expired licence)  
Preparation: prepare a customer whose licenceexpiry = today.  
Actions: logged in - View available cars.  
Expected: "Licence expired. Renew it to proceed."

3) Booking & OTP

Dates use YYYY-MM-DD. Weeks are rounded up to base fee of ($50/week).

TC9 - Find booking (valid dates)  
Login: cust / cust123.  
Steps: Create Booking- Car ID in the list, start 2025-09-16, end 2025-09-18.  
Expected:  
  - The created booking (PENDING) set available=0.  
  Booking ID, Base Fee (50 -1 week - 2 days), and OTP (6-digit, 5 min) are displayed on the console.

TC10 - Booking with the right OTP.  
Steps: "Confirm Booking (OTP)- booking ID + OTP TC9.  
Expected: "Booking confirmed." Status is CONFIRMED on receipt.

TC11 - Confirm with wrong OTP  
Procedure: type in not generated 6-digit randomly.  
Expected: "Invalid OTP."

TC12 - validate expired/used OTP.  
Instructions: wait 5 min or reuse OTP.  
Predicted: OTP has expired or been used.

TC13 - Invalid date format  
Steps: Create Booking - enter 16-09-2025.  
Expected: "Date format error. Use YYYY-MM-DD."

TC14 - End date before start date  
Steps: Booking Creation - start 2025-09-20, end 2025-09-18.  
Expected: "start date should come before end date.

TC15 - unavailable car (two bookings)  
Steps: Book the same Car ID when unavailable/held.  
Expected: "Car unavailable."

4) Admin Flow (Return, Approve, Pay)

TC16 - Approve booking (admin)  
Login: admin / admin123.  
Navigation: " Approve Booking" -Booking ID ( CONFIRMED).  
Expected: "Booking approved." Status APPROVED.

TC17 - Reject booking (admin)  
Actions: "Reject Booking" - PENDING/ CONFIRMED booking ID.  
Status REJECTED should be expected, car released available=1.

TC18 - Return on time (no late fee)  
Steps: "Return Car" - actual date is the end date of booking.  
Expected: "Return complete. Late=0 day(s). Final fee = base fee." Status COMPLETED, car released.

TC19 - Return late (3 days)  
Actions: Return Car - actual date = end date +3 days.  
Expected: Late = 3 - +$30. Status COMPLETED and final fee printed.

TC20 - Mark payment PAID (valid methods)  
Steps: "Payment Mark as PAID" - method CASH / CARD / ONLINE.  
Should happen: Paid payment saved, method saved, paymentdate saved; received paymentline.

TC21 - Mark payment (with invalid method)  
Steps: method UPI, NETBANK, etc.  
Expected: "Invalid method. Use CASH / CARD / ONLINE."

5) My Bookings (Customer)

TC22 - View my bookings (list)  
Login: cust / cust123.  
Steps: "View My Bookings".  
Expected: The following table is a list in reverse: ID, Car start-end fee status, payment.

6) Role-Based Menu

TC23 - Menu before login  
Steps: run the app.  
Anticipated: Register / Login / Exit only.

TC24 - Menu after customer login  
Steps: login cust / cust123.  
Predicted: Customer options only + Logout/Exit (no items of an administrator).

TC25 - Menu after admin login  
Steps: log in as admin / admin123.  
Expected: admin options only + recent exit/log out (no items as a customer).

7) Negative & Edge

TC26 - Unique username is registered.  
Steps: register cust again.  
Usernames: This should not be used because the user name is already in use.

TC27 - The date on which the individual returns is not valid.  
Steps: "Return Car" - 20-09-2025.  
Expected: "Date format error. Use YYYY-MM-DD."

TC28 - Accept/Reject non-existing booking.  
Steps: use a big ID (e.g., 99999).  
Expected: "Booking not found." (or no row changed).

TC29 - Verify OTP- wrong booking identities.  
Instructions: provide an acceptable code using a different booking and an incorrect ID.  
Expected: "Invalid OTP."

8) Basic Manual Test Script (Happy Path)

Log in as a customer (cust/cust123).  
See cars on offer - make a note of the Car ID.  
Make Booking - select Car ID, start 2025-09-16, end 2025-09-18.  
OTP and note bookings ID printed.  
Confirm Booking (OTP) - fill in both.  
Logout - Login as admin.  
Accept Booking - with that Booking ID.  
Return Car actual date = end date + 2 days ( late x = 2 - +$20).  
Make payment as PAID - method CARD.  
log out - customer log in - See my bookings - confirm final amount and PAID.

9) Evidence to Capture (Screenshots)

S1: Customer is able to successfully log in (role displayed)  
S2: Available cars list  
S3: generate booking summary (Booking ID, fee, OTP)  
S4: Booking confirmation (receipt is CONFIRMED)  
S5: Admin approve  
S6: Issue late fee summary (COMPLETED)  
S7: Mark payment PAID (receipt shows method+date)  
S8: "View My Bookings" list

10) Notes

Base fee = 50/week, rounded up (1-7days=50, 8-14=100, etc.).  
Late fee = 10 /day (actualreturndate [?] enddate, min 0).  
OTP 6-digit, 5-minute, one-time.  
Role-based menu: the menu only shows the relevant options according to role.  
In case schema errors are observed, remove carrental.db and rerun (set updatabase() will create and populate defaults).