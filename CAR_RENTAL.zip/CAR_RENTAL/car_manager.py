# car_manager.py — Car CRUD + listing

from database import get_connection, get_user
from datetime import date

def add_car(make, model, year, mileage):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""INSERT INTO cars(make,model,year,mileage,available)
                   VALUES (?,?,?,?,1)""", (make, model, year, mileage))
    conn.commit()
    conn.close()
    print("Car added.")

def list_all_cars():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, make, model, year, mileage, available FROM cars ORDER BY id")
    rows = cur.fetchall()
    conn.close()
    for r in rows:
        a = "Yes" if r[5] == 1 else "No"
        print(f"{r[0]}: {r[1]} {r[2]} ({r[3]}), {r[4]}km, Available: {a}")

def update_car_availability(car_id, is_available: bool):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE cars SET available=? WHERE id=?", (1 if is_available else 0, car_id))
    conn.commit()
    conn.close()
    print("Availability updated.")

def delete_car(car_id):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM cars WHERE id=?", (car_id,))
    conn.commit()
    conn.close()
    print("Car deleted.")

def view_available_cars_for_customer(username):
    """Check eligibility (age≥18, licence valid) then show available cars."""
    u = get_user(username)
    if not u:
        print("User not found.")
        return
    age = int(u[4] or 0)
    licence_expiry = (u[7] or "1970-01-01")
    if age < 18:
        print("You must be 18 or older to view cars.")
        return
    if licence_expiry <= date.today().isoformat():
        print("Licence expired. Renew it to proceed.")
        return

    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, make, model, year, mileage FROM cars WHERE available=1 ORDER BY id")
    rows = cur.fetchall()
    conn.close()

    if not rows:
        print("(No cars available right now.)")
        return

    print("\nAvailable cars:")
    for r in rows:
        print(f"{r[0]}: {r[1]} {r[2]} ({r[3]}), {r[4]}km")
