# booking_manager.py — Booking lifecycle, OTP, fees, payment

from database import get_connection, get_user
from datetime import datetime, date, timedelta
import random

def _parse(d):
    return datetime.strptime(d, "%Y-%m-%d").date()

def _weeks_ceil(days):
    return (days + 6) // 7

def show_booking(booking_id):
    conn = get_connection()
    cur = conn.cursor()
    b = cur.execute("""
        SELECT b.id, b.customer_username, b.car_id, b.start_date, b.end_date,
               b.fee, b.status, b.payment_status, b.payment_method, b.payment_date,
               c.make, c.model, c.year
        FROM bookings b
        JOIN cars c ON c.id = b.car_id
        WHERE b.id=?
    """, (booking_id,)).fetchone()
    conn.close()
    if not b:
        print("Booking not found."); return
    (bid, user, car_id, s, e, fee, status, pay_status, pay_method, pay_date,
     make, model, year) = b
    print("------------------------------------------------")
    print(f" Booking #{bid} | {make} {model} ({year}) [Car ID {car_id}]")
    print(f" Customer: {user}")
    print(f" Period  : {s} → {e}")
    print(f" Fee     : ${fee} | Status: {status} | Payment: {pay_status}")
    if pay_method:
        print(f" Payment : {pay_method} on {pay_date}")
    print("------------------------------------------------")

def view_my_bookings(customer_username):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT id, car_id, start_date, end_date, fee, status, payment_status
        FROM bookings
        WHERE customer_username=?
        ORDER BY id DESC
    """, (customer_username,))
    rows = cur.fetchall()
    conn.close()
    if not rows:
        print("\n(No bookings yet.)")
        return
    print("\n--- Your Bookings ---")
    for r in rows:
        bid, car_id, s, e, fee, st, pay = r
        print(f"ID {bid} | Car {car_id} | {s} → {e} | ${fee} | {st} | {pay}")

def create_booking(customer_username, car_id, start_date, end_date):
    u = get_user(customer_username)
    if not u:
        print("User not found."); return
    age = int(u[4] or 0)
    licence_expiry = (u[7] or "1970-01-01")
    if age < 18:
        print("Booking blocked: under 18."); return
    if licence_expiry <= date.today().isoformat():
        print("Booking blocked: licence expired."); return

    try:
        s = _parse(start_date); e = _parse(end_date)
    except ValueError:
        print("Date format error. Use YYYY-MM-DD (e.g., 2025-09-12)."); return
    if e <= s:
        print("End date must be after start date."); return

    days = (e - s).days
    weeks = _weeks_ceil(days)
    base_fee = weeks * 50

    conn = get_connection(); cur = conn.cursor()

    car = cur.execute("SELECT make, model, year, available FROM cars WHERE id=?", (car_id,)).fetchone()
    if not car:
        print("Car not found."); conn.close(); return
    make, model, year, available = car
    if available == 0:
        print("Car unavailable."); conn.close(); return

    cur.execute(
        """INSERT INTO bookings(customer_username,car_id,start_date,end_date,fee,status,payment_status)
           VALUES (?,?,?,?,?, 'PENDING','UNPAID')""",
        (customer_username, car_id, s.isoformat(), e.isoformat(), base_fee)
    )
    booking_id = cur.lastrowid
    cur.execute("UPDATE cars SET available=0 WHERE id=?", (car_id,))

    code = str(random.randint(100000, 999999))
    exp  = (datetime.utcnow() + timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
    cur.execute("INSERT INTO booking_otps(booking_id,code,expires_at,used) VALUES (?,?,?,0)",
                (booking_id, code, exp))

    conn.commit(); conn.close()

    print("\nBooking created (PENDING). Please confirm with OTP to finalize.")
    print(f" Booking ID : {booking_id}")
    print(f" Car        : {make} {model} ({year}) [ID {car_id}]")
    print(f" Start Date : {s} | End Date: {e}  (Total {days} days → billed {weeks} week(s))")
    print(f" Base Fee   : ${base_fee}")
    print(f" OTP        : {code}  (valid 5 minutes)\n")

def confirm_booking_with_otp(booking_id, code):
    conn=get_connection(); cur=conn.cursor()
    now=datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    row=cur.execute(
        """SELECT id,expires_at,used FROM booking_otps
           WHERE booking_id=? AND code=? ORDER BY id DESC LIMIT 1""",
        (booking_id,code)).fetchone()
    if not row:
        print("Invalid OTP."); conn.close(); return
    otp_id, exp, used=row
    if used==1 or exp<now:
        print("OTP expired or already used."); conn.close(); return
    cur.execute("UPDATE booking_otps SET used=1 WHERE id=?", (otp_id,))
    cur.execute("UPDATE bookings SET status='CONFIRMED' WHERE id=?", (booking_id,))
    conn.commit(); conn.close()
    print("Booking confirmed.")
    show_booking(booking_id)

def approve_booking(booking_id):
    conn=get_connection(); cur=conn.cursor()
    cur.execute("UPDATE bookings SET status='APPROVED' WHERE id=?", (booking_id,))
    conn.commit(); conn.close(); print("Booking approved.")

def reject_booking(booking_id):
    conn=get_connection(); cur=conn.cursor()
    car=cur.execute("SELECT car_id FROM bookings WHERE id=?", (booking_id,)).fetchone()
    if not car: print("Booking not found."); conn.close(); return
    cur.execute("UPDATE bookings SET status='REJECTED' WHERE id=?", (booking_id,))
    cur.execute("UPDATE cars SET available=1 WHERE id=?", (car[0],))
    conn.commit(); conn.close(); print("Booking rejected, car released.")

def return_car(booking_id, actual_date):
    conn=get_connection(); cur=conn.cursor()
    b=cur.execute("SELECT car_id,end_date,fee FROM bookings WHERE id=?", (booking_id,)).fetchone()
    if not b: print("Booking not found."); conn.close(); return
    car_id,end_date,fee=b
    try:
        late=max(0, (_parse(actual_date)-_parse(end_date)).days)
    except ValueError:
        print("Date format error. Use YYYY-MM-DD."); conn.close(); return
    total=fee+late*10
    cur.execute("UPDATE bookings SET fee=?,status='COMPLETED' WHERE id=?", (total,booking_id))
    cur.execute("UPDATE cars SET available=1 WHERE id=?", (car_id,))
    conn.commit(); conn.close()
    print(f"Return complete. Late={late} day(s). Final fee=${total}")
    show_booking(booking_id)

def mark_payment(booking_id, method):
    method = (method or "").strip().upper()
    if method not in ("CASH","CARD","ONLINE"):
        print("Invalid method. Use CASH / CARD / ONLINE.")
        return
    conn=get_connection(); cur=conn.cursor()
    from datetime import date
    cur.execute("UPDATE bookings SET payment_status='PAID',payment_method=?,payment_date=? WHERE id=?",
                (method, date.today().isoformat(), booking_id))
    conn.commit(); conn.close(); print("Payment marked PAID")
    show_booking(booking_id)

def view_all_bookings():
    conn=get_connection(); cur=conn.cursor()
    cur.execute("SELECT * FROM bookings ORDER BY id DESC")
    for r in cur.fetchall(): print(r)
    conn.close()
